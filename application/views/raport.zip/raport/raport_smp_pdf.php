<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?=$judul?></title>
	<link rel="stylesheet" href="<?= base_url('assets/css/').'smppdf.css' ?>">
</head>

<body>
	<div class="footer">SMP Al-Ittihad Camplong | <?= $kelas['kelas_alias'].' | Semester '.$semester.' | '.$nama ?> <span class="page-number"></span></div>
	<?php $id_santri = $this->uri->segment(3); $id_kelas=$this->uri->segment(4) ?>
	<?php  $CI =& get_instance(); ?>
	<div class="kertas">
	<h2 class="judul-utama">PENCAPAIAN KOMPETENSI SISWA</h2>
		<table class="atas">
			<tr>
				<td>Nama Sekolah</td>
				<td>:</td>
				<td>SMP AL ITTIHAD CAMPLONG</td>
				<td>Kelas</td>
				<td>:</td>
				<td><?=$kelas['kelas_alias'] ?></td>
			</tr>
			<tr>
				<?php 
					if ($semester == 1) {
						$semester_huruf = 'Ganjil';
					}else{
						$semester_huruf = 'Genap';
					}
				?>
				<td>Alamat</td>
				<td>:</td>
				<td>Jl. Raya Camplong No. 15 Sampang</td>
				<td>Semester</td>
				<td>:</td>
				<td><?= $semester.' / '.$semester_huruf ?></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td><?= $nama ?></td>
				<td>Tahun Pelajaran</td>
				<td>:</td>
				<td><?= $tahun ?></td>
			</tr>
			<tr>
				<td>NIS / NISN</td>
				<td>:</td>
				<td><?= isset($nis) ? $nis : '-' ?> / <?= isset($nisn) ? $nisn : '-' ?></td>
			</tr>
		</table>
		<h3 class="judul">A. Sikap</h3>
		<h4 class="sub-judul">1. Sikap Spiritual</h4>
		<div class="desk">
			<?= $CI->DeskSikap($id_santri)[0]['des']?>
		</div>
		<h4 class="sub-judul">2. Sikap Sosial</h4>
		<div class="desk">
			<?= $CI->DeskSikap($id_santri)[1]['des']?>
		</div>
		<h3 class="judul">B. Pengetahuan dan Keterampilan</h3>
		<!-- <h4 class="sub-judul">Ketuntasan Belajar Minimal: 75</h4> -->
		<table>
			<thead>
				<tr>
					<td colspan="2" rowspan="2">Mata Pelajaran</td>
					<td colspan="3">Pengetahuan</td>
					<td colspan="3">Keterampilan</td>
				</tr>
				<tr>
					<td style="text-align: center; font-size: 15px">Ang-<br>ka</td>
					<td style="text-align: center; center; font-size: 15px">Pre-<br>dikat</td>
					<td>Pengetahuan</td>
					<td style="text-align: center; center; font-size: 15px">Ang-<br>ka</td>
					<td style="text-align: center; center; font-size: 15px">Pre-<br>dikat</td>
					<td>Keterampilan</td>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="2">Kelompok A</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<?php $no=0; foreach ($dkn[414]['nilai'] as $k => $mp): ?>
				<?php if ($no==7): ?>
					<tr>
						<td colspan="2">Kelompok B</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>					
				<?php endif ?>
				<tr>
					<td><?= $no++ > 6 ? $no-7 : $no ?></td>
					<td><?= $mp['nama_mapel'] ?><br><p class="kkm">KKM:75</p></td>

					<td><?= $dkn[$id_santri]['nilai'][$k]['p'] ?></td>
					<td><?= $CI->hitungPredikat($dkn[$id_santri]['nilai'][$k]['p'], 75)[0] ?></td>
					<td style="font-size: 15px; width: 28%"><?= $CI->tampilPredikat($id_santri, $id_kelas, $k, 'p') ?></td>

					<td><?= $dkn[$id_santri]['nilai'][$k]['k'] ?></td>
					<td><?= $CI->hitungPredikat($dkn[$id_santri]['nilai'][$k]['k'], 75)[0] ?></td>
					<td style="font-size: 15px;  width: 28%"><?= $CI->tampilPredikat($id_santri, $id_kelas, $k, 'k') ?></td>
				</tr>
				<?php endforeach ?>
			</tbody>
		</table>
		<h3 class="judul">C. Ektrakurikulier</h3>
		<table class="lebar">
			<tr>
				<th>No</th>
				<th>Nama Kegiatan</th>
				<th>Nilai</th>
				<th>Keterangan</th>
			</tr>
			<tr>
				<td>1</td>
				<td>Pramuka</td>
				<td><?= $entry_wali['des_pramuka'] ?></td>
				<td><?= $entry_wali['predikat_pramuka'] ?></td>
			</tr>
			<tr>
				<td>2</td>
				<td>OSIS/ISMII</td>
				<td><?= $entry_wali['des_ismi'] ?></td>
				<td><?= $entry_wali['predikat_ismi'] ?></td>
			</tr>
			<tr>
				<td>3</td>
				<td>Jurnalistik</td>
				<td><?= $entry_wali['des_sorasi'] ?></td>
				<td><?= $entry_wali['predikat_sorasi'] ?></td>
			</tr>
			<tr>
				<td>4</td>
				<td>Tahfidzul Qur'an</td>
				<td><?= $entry_wali['des_tahfid'] ?></td>
				<td><?= $entry_wali['predikat_tahfid'] ?></td>
			</tr>
		</table>
		<div class="keputusan">
			<div class="kiri">
				<h3 class="judul">D. Ketidakhadiran</h3>
				<table class="lebar">
					<tr>
						<th>Keterangan</th>
						<th>Jumlah</th>
					</tr>
					<tr>
						<td>Sakit</td>
						<td><?= $entry_wali['sakit'] ?> Hari</td>
					</tr>
					<tr>
						<td>Idzin</td>
						<td><?= $entry_wali['ijin'] ?> Hari</td>
					</tr>
					<tr>
						<td>Tanpa Keterangan</td>
						<td><?= $entry_wali['alpa'] ?> Hari</td>
					</tr>
				</table>
			</div>
			<div class="kanan">
				<p style="font-size: 18px; font-weight: bold; border-bottom: 1px solid grey; padding: 9px 5px 9px 5px;">Keputusan:</p> 
				<p>Berdasarkan pencapaian kompetensi pada semester ke-1 dan ke-2, Siswa ditetapkan:</p>

				<p style="font-weight: bold;">Naik ke Kelas <?= $kelas_baru[0].' ('.$kelas_baru[1].')' ?></p>
			</div>
		</div>
		<div style="clear: left;"></div>
		<div class="ttd">
			<div class="tgl">
				<div class="bagi-dua">
					Mengetahui,
				</div>
				<div class="bagi-dua" style="margin-top: 0; ">
					Sampang, 11 Oktober 2015
				</div>
			</div>
			<div class="tempat-ttd cf">
				<div class="bagi-tiga">
					<div class="sebagai">Orang Tua/Wali</div>
					<div class="isi">________________________</div>
				</div>
				<div class="bagi-tiga">
					<div class="sebagai">Wali Kelas</div>
					<div class="isi"><u><?= $wali['nama_asatid'] ?></u><br>NIY. <?= $wali['niy'] ?></div>
				</div>

				<div class="bagi-tiga">
					<div class="sebagai">Kepala Sekolah</div>
					<div class="isi"><u>Mudhar, S.Pd.</u> <br> NIY. 940613051</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>